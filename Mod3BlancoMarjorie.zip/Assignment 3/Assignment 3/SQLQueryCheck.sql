
-- Report 1: Checks
SELECT        SUM(FactResellerSales.SalesAmount) AS SalesAmount
FROM          FactResellerSales


SELECT        DimProductCategory.EnglishProductCategoryName AS [Product Category], SUM(FactResellerSales.SalesAmount) AS SalesAmount
FROM          FactResellerSales INNER JOIN
                         DimProduct ON FactResellerSales.ProductKey = DimProduct.ProductKey INNER JOIN
                         DimProductSubcategory ON DimProduct.ProductSubcategoryKey = DimProductSubcategory.ProductSubcategoryKey INNER JOIN
                         DimProductCategory ON DimProductSubcategory.ProductCategoryKey = DimProductCategory.ProductCategoryKey
GROUP BY DimProductCategory.EnglishProductCategoryName
ORDER BY [Product Category]



SELECT        DimProductCategory.EnglishProductCategoryName AS [Product Category], DimProductSubcategory.EnglishProductSubcategoryName AS [Product Subcategory], SUM(FactResellerSales.SalesAmount) AS SalesAmount
FROM          FactResellerSales INNER JOIN
                         DimProduct ON FactResellerSales.ProductKey = DimProduct.ProductKey INNER JOIN
                         DimProductSubcategory ON DimProduct.ProductSubcategoryKey = DimProductSubcategory.ProductSubcategoryKey INNER JOIN
                         DimProductCategory ON DimProductSubcategory.ProductCategoryKey = DimProductCategory.ProductCategoryKey
GROUP BY DimProductCategory.EnglishProductCategoryName, DimProductSubcategory.EnglishProductSubcategoryName
ORDER BY [Product Category], [Product Subcategory]

-- Report 2: Checks

SELECT        SUM(FactResellerSales.SalesAmount) AS [Sales Amount]
FROM            FactResellerSales INNER JOIN
                         DimReseller ON FactResellerSales.ResellerKey = DimReseller.ResellerKey

SELECT        DimReseller.BusinessType AS [Business Type], SUM(FactResellerSales.SalesAmount) AS [Sales Amount]
FROM            FactResellerSales INNER JOIN
                         DimReseller ON FactResellerSales.ResellerKey = DimReseller.ResellerKey
GROUP BY DimReseller.BusinessType
ORDER BY [Business Type]

SELECT        DimReseller.BusinessType AS [Business Type], DimReseller.ResellerName AS [Reseller Name], SUM(FactResellerSales.SalesAmount) AS [Sales Amount]
FROM            FactResellerSales INNER JOIN
                         DimReseller ON FactResellerSales.ResellerKey = DimReseller.ResellerKey
GROUP BY DimReseller.BusinessType, DimReseller.ResellerName
ORDER BY [Business Type], [Reseller Name]
